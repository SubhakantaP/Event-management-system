<title>Campus Event FCRIT</title>
<style>
.bgImage {
    background-color: darkblue;
    background-size: cover;
    background-position: center center;
    height: 100px;
    margin-bottom: 25px;
}
</style>
<header class="bgImage" > 
    <nav class="navbar" >
        <div class="container">
        <div class="navbar-header"><!--website name/title--> 
                <a class = "navbar-brand">
                   <h2>Campus Event FCRIT</h2>
                </a>
        </div>
            <ul class="nav navbar-nav navbar-right"><!--navigation-->
                    <li><a href = "index.php"><strong>Home</strong></a></li>
                    <li><a href = "register.php"><strong>Register For Event</strong></a></li>
                    <li class="btnlogout"><a class = "btn btn-default navbar-btn" href = "login_form.php">Login <span class = "glyphicon glyphicon-log-in"></span></a></li>   
            </ul>
        </div><!--container div-->
    </nav>
</header>